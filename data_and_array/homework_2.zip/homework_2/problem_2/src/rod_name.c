/*
** CCU PROJECT, 2025
** problem_two.c
** File description:
** print rods and moves information
*/

#include "problem_two.h"

char rod_name(int idx)
{
    return "ABC"[idx];
}
